import java.util.Scanner;

//public class SimpleMusicTrack{


public class SimpleMusicTrack implements PlayListTrack {
	private String name;
	private String artist;
	private String albumName;

	public SimpleMusicTrack(){}
	
	public SimpleMusicTrack(String name, String artist, String album){
	this.name=name;
	this.artist=artist;
	this.albumName=album;
	}
	
	public String getName() {
		return this.name;
		}
	public void setName(String name) {
		this.name=name;
		}
	public String getArtist() {
		return this.artist;
		}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getAlbum() {
		return this.albumName;
		}
	public void setAlbum(String album) {
		this.albumName=album;
		}
	
	public boolean getNextTrack(Scanner infile) {
		if(infile==null)
		return false;
		while(infile.hasNext()){
		this.setName(infile.nextLine());
		this.setArtist(infile.nextLine());
		this.setAlbum(infile.nextLine());
		return true;
		}
		return false;
		}
	
	public boolean equals(Object obj){
		try {
			if (obj instanceof SimpleMusicTrack) {
				if ((this.name == ((SimpleMusicTrack) obj).getName())
						&& (this.artist == ((SimpleMusicTrack) obj).getArtist())
						&& (this.albumName == ((SimpleMusicTrack) obj).getAlbum())) {
					return true;
				}
			}
			return false;
		} catch (Exception e){
			return false;
		}
	}
	
	public String toString(){
		return "'" + getArtist() + " / " + getName() + "'";
		}
	}
