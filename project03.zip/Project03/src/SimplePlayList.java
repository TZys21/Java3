import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class SimplePlayList implements PlayList {
	public ArrayList<PlayListTrack> list = new ArrayList<PlayListTrack>();

	public SimplePlayList(PlayListTrack track) {
		addTrack(track);
	}
	
	public PlayListTrack getNextTrack() {
		PlayListTrack track;
		track = this.list.get(0);
		this.list.remove(0);
		return track;
	}
	
	public PlayListTrack peekAtNextTrack() {
		return this.list.get(0);
	}
	
	
	public void remainingTracks() {
		if (list.size() == 0) {
			System.out.println("No tracks remaining");
		} else {
			for (int i = 0; i < list.size(); i++) {
				System.out.print(i + 1 + ".) ");
				System.out.println(this.list.get(i).getArtist() + " / "
						+ this.list.get(i).getName() + " / "
						+ this.list.get(i).getAlbum());
			}
			list.clear();
		}
	}
	
	public void addTrack(PlayListTrack track) {
		this.list.add(track);
	}
	
	public boolean isEmpty() {
		if (this.list.size() >= 1) {
			return true;
		} else {
			return false;
		}
	}
	
	public int songsinPlaylist(){
		int quantity = list.size();
		return quantity;
}

}
	

