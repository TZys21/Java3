import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Project03 {
	public static void main(String[] args) {
		Project03 startProject03 = new Project03();
	}

	
		PlayListTrack track = new SimpleMusicTrack();
		Scanner infile = new Scanner(System.in);
		SimplePlayList playList;
		String selection = "null";
		int trackInPlayCounter = 0;

		
		public Project03() {
			playList = new SimplePlayList(track);
			getFile();
			while (!(selection.equals("Q"))) {
				try{
					userInterface();
				} catch (Exception e){
					System.out.println("Ivalid entry. System shutting down.");
					System.exit(0);
				}
			}
		}


		private void getFile() {
			System.out.print("Enter database filename: ");
			String filename = infile.nextLine();
			File inputFile = new File(filename);
			Scanner file;
			try {
				file = new Scanner(inputFile);
				track.getNextTrack(file);
			
			} catch (FileNotFoundException e) {
				file = null;
				file.close();
				throw new IllegalArgumentException("You must enter a valid file.");
			}
			while (file.hasNext() == true) {
				PlayListTrack track = new SimpleMusicTrack();
				track.getNextTrack(file);
				playList.addTrack(track);
			}
		}
		
		
		public void selectionP(){
			track = playList.getNextTrack();
			this.trackInPlayCounter += 1;
		}
		
		public void selectionA(){
			System.out.println("Track name:");
			String name = infile.nextLine();
			System.out.println("Artist name:");
			String artist = infile.nextLine();
			System.out.println("Album name:");
			String album = infile.nextLine();
			
			PlayListTrack newTrack = new SimpleMusicTrack(name, artist,
					album);
			System.out.println("New track: " + newTrack.getName());
			System.out.println("Artist: " + newTrack.getArtist());
			System.out.println("Album: " + newTrack.getAlbum());

			System.out.println("Are you sure you want to add this track [y/n]?");
			String validity = infile.nextLine();

			if ((validity.equals("y") || validity.equals("Y"))) {
				playList.addTrack(newTrack);
			} else {
				this.selection = "no selection";
			}
		}
		
		public void selectionQ(){
			System.out.println("Tracks remaining in playlist: ");
			playList.remainingTracks();
			System.out.println();
			this.selection = "Q";
			System.exit(0);
		}
		public void getSelection(){
			if (playList.songsinPlaylist() >= 1){
				System.out.println("[P]lay next track");
			}
			System.out.println("[A]dd a new track");
			System.out.println("[Q]uit");
			selection = infile.nextLine();
		}
		
		public void userInterface() {
			if ((selection != "P") && (selection != "p") && (selection != "A") && (selection != "a") && (selection != "Q") && (selection != "q") && (selection != null)){
				selection = null;
				userInterface();
			} else { 
				if (this.trackInPlayCounter == 0) {
					System.out.println("Currently playing: No Song Playing");
				} else if (playList.songsinPlaylist()+ 1 == 0){
					System.out.println("Currently playing: There are no songs remaining in playlist");
				} else {
					System.out.println("Currently playing: " + track.toString());
				}
				
				if (playList.songsinPlaylist() >= 1){
					System.out.println("Next track to play: " + playList.peekAtNextTrack());
				} else {
					System.out.println("Next track to play: No songs remaining in playlist");
				}
				
				getSelection();
			
			//If user selects "P"
			if ((selection.equals("p")) || (selection.equals("P"))) {
				selectionP();
		
			//If user selects "A"
			} else if ((selection.equals("a")) || (selection.equals("A"))) {
				selectionA();

			//If user selects "Q"
			} else if ((selection.equals("q")) || (selection.equals("Q"))) {
				selectionQ();
			}
		}
	}
		
		
		}

	


